package stepDefinitions ;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import testBase.TestBase;
import stepImplmentation.StepImplmentation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ScenariosStepDefinition extends TestBase {
    StepImplmentation stepImp = new StepImplmentation();

    @Given(": launch browser with url {string}")
    public void launch_browser_with_url(String url) {
    launch_Browser(url);
    }
    @When(": user register new account")
    public void user_register_new_account(DataTable dt) {
        stepImp.press_signup_btn();
        List<Map<String, String>> listOfMaps = new ArrayList<Map<String,String>>();
        listOfMaps=dt.asMaps();

        stepImp.add_basic_info(listOfMaps);

    }
    @When(": user search for this user {string}")
    public void user_search_this_user(String userId) {
      stepImp.search_for_user(userId);
    }
    @When(": user follow this user {string}")
    public void user_follow_this_user(String userId) {
    stepImp.follow_user(userId);
    }

    @When(": User sign out")
    public void user_sign_out() {
        stepImp.sign_out();
    }

    @When(": user login with account")
    public void user_login_with_account(DataTable dt)
    {
        List<Map<String, String>> listOfMaps = new ArrayList<Map<String,String>>();
        listOfMaps=dt.asMaps();
        stepImp.login(listOfMaps);

    }
}
