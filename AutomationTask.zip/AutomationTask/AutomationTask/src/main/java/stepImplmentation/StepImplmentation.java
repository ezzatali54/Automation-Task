package stepImplmentation;

import io.cucumber.datatable.DataTable;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;
import testBase.TestBase;

import java.time.Duration;
import java.util.List;
import java.util.Map;

public class StepImplmentation extends testBase.TestBase {

    public StepImplmentation()
    {
      PageFactory.initElements(driver, this);
    }
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    @FindBy(xpath = "//a[@href='/i/flow/signup']")
    WebElement signup;
    @FindBy(xpath = "//input[@name = 'name']")
    WebElement name;
    @FindBy(xpath = "//input[@name = 'email']")
    WebElement email;
    @FindBy(xpath = "//div[2]/select")
    WebElement dateOfBirthDay;
    @FindBy(xpath = "//div[1]/select")
    WebElement dateOfBirthMonth;
    @FindBy(xpath = "//div[3]/select")
    WebElement dateOfBirthYear;
    @FindBy(xpath = "//div[@data-testid='ocfSignupNextLink']")
    WebElement firstNxtBtn;
    @FindBy(xpath = "//div[@data-testid='ocfSettingsListNextButton']")
    WebElement secondNxtBtn;
    @FindBy(xpath = "//div[@data-testid='ocfSignupReviewNextLink']")
    WebElement signUpBtn;
    @FindBy(xpath = "//input[@placeholder='Search']")
    WebElement searchInput;
    @FindBy(xpath = "//div[@data-testid='typeaheadResult'][2]/div")
    WebElement searchResult;
    @FindBy(xpath = "//div[@data-testid='SideNav_AccountSwitcher_Button']")
    WebElement accountsBtn;
    @FindBy(xpath = "//a[@href='/logout']")
    WebElement signOut;
    @FindBy(xpath = "//div[@data-testid='confirmationSheetConfirm']")
    WebElement confirmLogOut;
    @FindBy(xpath = "//a[@href='/login']")
    WebElement signIn;
    @FindBy(xpath = "//input[@autocomplete='username']")
    WebElement loginEmail;
    @FindBy(xpath = "//div[@role='button'][2]")
    WebElement loginNextBtn;
    @FindBy(xpath = "//input[@name='password']")
    WebElement loginPassword;
    @FindBy(xpath = "//div[@data-testid='LoginForm_Login_Button']")
    WebElement loginBtn;

    public void press_signup_btn()
    {
        wait.until(ExpectedConditions.visibilityOf(signup));
        wait.until(ExpectedConditions.elementToBeClickable(signup));
        signup.click();
    }

    public void add_basic_info(List<Map<String, String>> listOfMaps)
    {
        String userName = listOfMaps.get(0).get("name");
        String userEmail = listOfMaps.get(0).get("email");
        String userDayOfBirth = listOfMaps.get(0).get("day of birth");
        String userMonthOfBirth = listOfMaps.get(0).get("month of birth");
        String userYearOfBirth = listOfMaps.get(0).get("year of birth");

        wait.until(ExpectedConditions.visibilityOf(name));
        name.sendKeys(userName);
        email.sendKeys(userEmail);

        Select dobm = new Select(dateOfBirthMonth);
        dobm.selectByVisibleText(userMonthOfBirth);

        wait.until(ExpectedConditions.elementToBeClickable(dateOfBirthDay));
        Select dobd = new Select(dateOfBirthDay);
        dobd.selectByVisibleText(userDayOfBirth);

        wait.until(ExpectedConditions.elementToBeClickable(dateOfBirthYear));
        Select doby = new Select(dateOfBirthYear);
        doby.selectByVisibleText(userYearOfBirth);

        wait.until(ExpectedConditions.elementToBeClickable(firstNxtBtn)).click();

        wait.until(ExpectedConditions.visibilityOf(secondNxtBtn));
        wait.until(ExpectedConditions.elementToBeClickable(secondNxtBtn)).click();

        wait.until(ExpectedConditions.visibilityOf(signUpBtn));
        wait.until(ExpectedConditions.elementToBeClickable(signUpBtn)).click();

    }
    public void search_for_user(String userId) {
        wait.until(ExpectedConditions.visibilityOf(searchInput));
        searchInput.sendKeys(userId);
          wait.until(ExpectedConditions.visibilityOf(searchResult));
            wait.until(ExpectedConditions.elementToBeClickable(searchResult)).click();


    }
    public void follow_user(String userId) {
          wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@aria-label='Follow "+userId+"']"))));
            wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//div[@aria-label='Follow "+userId+"']")))).click();

    }

    public void sign_out()
    {
        wait.until(ExpectedConditions.elementToBeClickable(accountsBtn)).click();
        wait.until(ExpectedConditions.visibilityOf(signOut));
        wait.until(ExpectedConditions.elementToBeClickable(signOut)).click();
        wait.until(ExpectedConditions.visibilityOf(confirmLogOut));
        wait.until(ExpectedConditions.elementToBeClickable(confirmLogOut)).click();
    }
    public void login(List<Map<String, String>> listOfMaps) {
        String userName = listOfMaps.get(0).get("email");
        String userPassword = listOfMaps.get(0).get("password");

    wait.until(ExpectedConditions.visibilityOf(signIn));
    wait.until(ExpectedConditions.elementToBeClickable(signIn)).click();

        wait.until(ExpectedConditions.visibilityOf(loginEmail));
        loginEmail.sendKeys(userName);
        loginNextBtn.click();

        wait.until(ExpectedConditions.visibilityOf(loginPassword));
        loginPassword.sendKeys(userPassword);
        loginBtn.click();


    }

}

