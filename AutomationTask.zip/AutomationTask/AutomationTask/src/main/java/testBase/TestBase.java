package testBase;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
public class TestBase extends AbstractTestNGCucumberTests {

    public static WebDriver driver = new ChromeDriver();

        public static void launch_Browser (String url) {
             WebDriverManager.chromedriver().setup();
            driver.get(url);


        }
    }

